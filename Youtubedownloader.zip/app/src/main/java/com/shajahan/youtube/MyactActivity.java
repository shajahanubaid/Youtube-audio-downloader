package com.shajahan.youtube;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class MyactActivity extends Activity {
	
	
	private WebView webview1;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.myact);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	private void initializeLogic() {
		webview1.loadUrl("data:text/html,".concat("\n<!DOCTYPE html><html><title>W3.CSS Template</title><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\"><link rel=\"stylesheet\" href=\"https://www.w3schools.com/lib/w3-theme-blue-grey.css\"><link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'><link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\"><style>html,body,h1,h2,h3,h4,h5 {font-family: \"Open Sans\", sans-serif}</style><body class=\"w3-theme-l5\"> <!-- Page Container --><div class=\"w3-container w3-content\" style=\"max-width:1400px;margin-top:80px\"> <!-- The Grid --> <div class=\"w3-row\"> <!-- Left Column --> <div class=\"w3-col m3\"> <!-- Profile --> <div class=\"w3-card w3-round w3-white\"> <div class=\"w3-container\"> <h4 class=\"w3-center\">Shajahan Ubaid</h4> <p class=\"w3-center\"><img src=\"https://avatars2.githubusercontent.com/u/33887787?s=400&u=59b9f6f98d5d10a837f6f25216984144bf5ddd36&v=4\" class=\"w3-circle\" style=\"height:106px;width:106px\" alt=\"\"></p> <hr> <p><i class=\"fa fa-pencil fa-fw w3-margin-right w3-text-theme\"></i> Designer, UI</p> <p><i class=\"fa fa-home fa-fw w3-margin-right w3-text-theme\"></i> India, Kerala</p> <p><i class=\"fa fa-birthday-cake fa-fw w3-margin-right w3-text-theme\"></i> November 29, 1988</p> </div> </div>\n\n<p> <a href=\"https://github.com/shajahanubaid\" target=\"_blank\">My github</a></p> <p><a href=\"https://www.w3schools.com/w3css/default.asp\" target=\"_blank\"></a></p>\n\n <br> <!-- Accordion --> <div class=\"w3-card w3-round\"> <div class=\"w3-white\"> <button onclick=\"myFunction('Demo1')\" class=\"w3-button w3-block w3-theme-l1 w3-left-align\"><i class=\"fa fa-circle-o-notch fa-fw w3-margin-right\"></i>https://github.com/shajahanubaid </button> <div id=\"Demo1\" class=\"w3-hide w3-container\"> <a href=\"https://github.com/shajahanubaid/default.asp\"></a> </div> \n\n\n<button onclick=\"myFunction('Demo2')\" class=\"w3-button w3-block w3-theme-l1 w3-left-align\"><i class=\"fa fa-calendar-check-o fa-fw w3-margin-right\"></i>Team clowns</button> <div id=\"Demo2\" class=\"w3-hide w3-container\"> <p><a href=\"https://tipze.blogspot.com/\">MALLU TIPS</a></p> </div> <button onclick=\"myFunction('Demo3')\" class=\"w3-button w3-block w3-theme-l1 w3-left-align\"><i class=\"fa fa-users fa-fw w3-margin-right\"></i> My team </button> <div id=\"Demo3\" class=\"w3-hide w3-container\"> <div class=\"w3-row-padding\"> <br> <div class=\"w3-half\"> <p>aysha</p> </div> <div class=\"w3-half\"> <p>Top-coder</p> </div> <div class=\"w3-half\"> <p>Ashiyana</p> </div> <div class=\"w3-half\"><p>The jocker</p> </div> </div> </div> </div> </div> <br> </div> <br> <!-- Alert Box --> <!-- End Left Column --> </div> </div> <!-- End Grid --></div> <!-- End Page Container --></div><br> <!-- Footer --><footer class=\"w3-container w3-theme-d3 w3-padding-16\"> <h5></h5></footer> <footer class=\"w3-container w3-theme-d5\"> <p>Powered by <a href=\"https://www.w3schools.com/w3css/default.asp\" target=\"_blank\">w3.css</a></p> <p><a href=\"https://www.w3schools.com/w3css/default.asp\" target=\"_blank\"></a></p></footer> <script>// Accordionfunction myFunction(id) { var x = document.getElementById(id); if (x.className.indexOf(\"w3-show\") == -1) { x.className += \" w3-show\"; x.previousElementSibling.className += \" w3-theme-d1\"; } else { x.className = x.className.replace(\"w3-show\", \"\"); x.previousElementSibling.className = x.previousElementSibling.className.replace(\" w3-theme-d1\", \"\"); }} // Used to toggle the menu on smaller screens when clicking on the menu buttonfunction openNav() { var x = document.getElementById(\"navDemo\"); if (x.className.indexOf(\"w3-show\") == -1) { x.className += \" w3-show\"; } else { x.className = x.className.replace(\" w3-show\", \"\"); }}</script> </body></html>\n\n\n"));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
