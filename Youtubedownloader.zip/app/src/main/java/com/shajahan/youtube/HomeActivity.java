package com.shajahan.youtube;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.EditText;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.webkit.WebViewClient;
import com.google.gson.Gson;
import android.Manifest;
import android.content.pm.PackageManager;

public class HomeActivity extends Activity {
	
	
	private String ip = "";
	private String load = "";
	private String download_path = "";
	private String filename = "";
	private String filetime = "";
	private String kd = "";
	
	private ArrayList<HashMap<String, Object>> download_complete = new ArrayList<>();
	
	private LinearLayout background;
	private LinearLayout tool_bar;
	private ScrollView vscroll1;
	private LinearLayout linear30;
	private LinearLayout linear4;
	private TextView textview1;
	private LinearLayout linear3;
	private LinearLayout linear_orta;
	private LinearLayout linear42;
	private EditText url;
	private LinearLayout linear32;
	private Button button2;
	private LinearLayout linear39;
	private LinearLayout linear36;
	private LinearLayout linear37;
	private LinearLayout linear45;
	private ScrollView vscroll3;
	private WebView webview;
	private TextView textview12;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private TextView textview7;
	private TextView textview8;
	private Button gitb;
	private TextView textview14;
	private Button ytb;
	private TextView textview15;
	private Button button3;
	private TextView textview16;
	private Button insta;
	
	private Calendar calendar = Calendar.getInstance();
	private SharedPreferences download_data;
	private AlertDialog.Builder d;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		background = (LinearLayout) findViewById(R.id.background);
		tool_bar = (LinearLayout) findViewById(R.id.tool_bar);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear30 = (LinearLayout) findViewById(R.id.linear30);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear_orta = (LinearLayout) findViewById(R.id.linear_orta);
		linear42 = (LinearLayout) findViewById(R.id.linear42);
		url = (EditText) findViewById(R.id.url);
		linear32 = (LinearLayout) findViewById(R.id.linear32);
		button2 = (Button) findViewById(R.id.button2);
		linear39 = (LinearLayout) findViewById(R.id.linear39);
		linear36 = (LinearLayout) findViewById(R.id.linear36);
		linear37 = (LinearLayout) findViewById(R.id.linear37);
		linear45 = (LinearLayout) findViewById(R.id.linear45);
		vscroll3 = (ScrollView) findViewById(R.id.vscroll3);
		webview = (WebView) findViewById(R.id.webview);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setSupportZoom(true);
		textview12 = (TextView) findViewById(R.id.textview12);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		gitb = (Button) findViewById(R.id.gitb);
		textview14 = (TextView) findViewById(R.id.textview14);
		ytb = (Button) findViewById(R.id.ytb);
		textview15 = (TextView) findViewById(R.id.textview15);
		button3 = (Button) findViewById(R.id.button3);
		textview16 = (TextView) findViewById(R.id.textview16);
		insta = (Button) findViewById(R.id.insta);
		download_data = getSharedPreferences("download_data", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!url.getText().toString().trim().equals("")) {
					_Convert(url.getText().toString(), true, false);
					download_path = "YouTube/download/musics";
					_download_manager(webview, download_path);
					webview.setInitialScale(105);
				}
				else {
					webview.loadUrl("https://www.yt-download.org/@api/button/mp3/YouTube-Video-ID");
				}
			}
		});
		
		webview.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		gitb.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview.loadUrl("https://github.com/shajahanubaid");
			}
		});
		
		ytb.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview.loadUrl("https://www.youtube.com/channel/UCBj_gP-y3sLhYlvPZAVaX9w");
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview.loadUrl("data:text/html,".concat("\n<!DOCTYPE html><html><title>W3.CSS Template</title><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\"><link rel=\"stylesheet\" href=\"https://www.w3schools.com/lib/w3-theme-blue-grey.css\"><link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'><link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\"><style>html,body,h1,h2,h3,h4,h5 {font-family: \"Open Sans\", sans-serif}</style><body class=\"w3-theme-l5\"> <!-- Page Container --><div class=\"w3-container w3-content\" style=\"max-width:1400px;margin-top:80px\"> <!-- The Grid --> <div class=\"w3-row\"> <!-- Left Column --> <div class=\"w3-col m3\"> <!-- Profile --> <div class=\"w3-card w3-round w3-white\"> <div class=\"w3-container\"> <h4 class=\"w3-center\">Shajahan Ubaid</h4> <p class=\"w3-center\"><img src=\"https://avatars2.githubusercontent.com/u/33887787?s=400&u=59b9f6f98d5d10a837f6f25216984144bf5ddd36&v=4\" class=\"w3-circle\" style=\"height:106px;width:106px\" alt=\"\"></p> <hr> <p><i class=\"fa fa-pencil fa-fw w3-margin-right w3-text-theme\"></i> Designer, UI</p> <p><i class=\"fa fa-home fa-fw w3-margin-right w3-text-theme\"></i> India, Kerala</p> <p><i class=\"fa fa-birthday-cake fa-fw w3-margin-right w3-text-theme\"></i> November 29, 1988</p> </div> </div>\n\n<p> <a href=\"https://github.com/shajahanubaid\" target=\"_blank\">My github</a></p> <p><a href=\"https://www.w3schools.com/w3css/default.asp\" target=\"_blank\"></a></p>\n\n <br> <!-- Accordion --> <div class=\"w3-card w3-round\"> <div class=\"w3-white\"> <button onclick=\"myFunction('Demo1')\" class=\"w3-button w3-block w3-theme-l1 w3-left-align\"><i class=\"fa fa-circle-o-notch fa-fw w3-margin-right\"></i>https://github.com/shajahanubaid </button> <div id=\"Demo1\" class=\"w3-hide w3-container\"> <a href=\"https://github.com/shajahanubaid/default.asp\"></a> </div> \n\n\n<button onclick=\"myFunction('Demo2')\" class=\"w3-button w3-block w3-theme-l1 w3-left-align\"><i class=\"fa fa-calendar-check-o fa-fw w3-margin-right\"></i>Team clowns</button> <div id=\"Demo2\" class=\"w3-hide w3-container\"> <p><a href=\"https://tipze.blogspot.com/\">MALLU TIPS</a></p> </div> <button onclick=\"myFunction('Demo3')\" class=\"w3-button w3-block w3-theme-l1 w3-left-align\"><i class=\"fa fa-users fa-fw w3-margin-right\"></i> My team </button> <div id=\"Demo3\" class=\"w3-hide w3-container\"> <div class=\"w3-row-padding\"> <br> <div class=\"w3-half\"> <p>aysha</p> </div> <div class=\"w3-half\"> <p>Top-coder</p> </div> <div class=\"w3-half\"> <p>Ashiyana</p> </div> <div class=\"w3-half\"><p>The jocker</p> </div> </div> </div> </div> </div> <br> </div> <br> <!-- Alert Box --> <!-- End Left Column --> </div> </div> <!-- End Grid --></div> <!-- End Page Container --></div><br> <!-- Footer --><footer class=\"w3-container w3-theme-d3 w3-padding-16\"> <h5></h5></footer> <footer class=\"w3-container w3-theme-d5\"> <p>Powered by <a href=\"https://www.w3schools.com/w3css/default.asp\" target=\"_blank\">w3.css</a></p> <p><a href=\"https://www.w3schools.com/w3css/default.asp\" target=\"_blank\"></a></p></footer> <script>// Accordionfunction myFunction(id) { var x = document.getElementById(id); if (x.className.indexOf(\"w3-show\") == -1) { x.className += \" w3-show\"; x.previousElementSibling.className += \" w3-theme-d1\"; } else { x.className = x.className.replace(\"w3-show\", \"\"); x.previousElementSibling.className = x.previousElementSibling.className.replace(\" w3-theme-d1\", \"\"); }} // Used to toggle the menu on smaller screens when clicking on the menu buttonfunction openNav() { var x = document.getElementById(\"navDemo\"); if (x.className.indexOf(\"w3-show\") == -1) { x.className += \" w3-show\"; } else { x.className = x.className.replace(\" w3-show\", \"\"); }}</script> </body></html>\n\n\n"));
			}
		});
		
		insta.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview.loadUrl("https://www.instagram.com/ig_.anubis/");
			}
		});
	}
	private void initializeLogic() {
		download_path = "YouTube/download";
		_Folders(download_path);
		_download_manager(webview, "YouTube/download");
		WebView synopsis; synopsis=(WebView)findViewById(R.id.webview);
		//synopsis.setBackgroundColor(Color.BLACK);
		webview.setInitialScale(148);
		webview.setVerticalScrollBarEnabled(false);
		//webview.setHorizontalScrollBarEnabled(false);
		/*
android.view.ViewGroup.LayoutParams lp = (android.widget.TableRow.LayoutParams) webview.getLayoutParams();    
lp.width=100;
lp.height=200;  
webview.setLayoutParams(lp);
*/
		kd = "YT2MP3 is an online service, which allows you to convert your favorite YouTube videos into high quality Mp3 files. It's actually pretty simple to use too. Just enter the YouTube URL of your favorite video and we will provide you with a download link to the Mp3 file within seconds.\n\nWe offer the fastest conversion speed in the market. There are no limits to the number of videos each user can convert. There are no limits on the length of videos either, unlike some other services in this space.\n\nYT2MP3 is designed to be mobile friendly. It looks and works great on any PC, Mac, Tablet, iPhone or Android device. There is no software installation required. Just use your favorite browser on your device of choice. And best of all, it's absolutely free.\nIf you are a web developer and want to use our API. Try it its super fast and supports multiple bitrates like 128 kbps, 192 kbps, 256 kbps & 320 kbps.";
		
		
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		
	}
	
	@Override
	public void onBackPressed() {
		if (webview.canGoBack()) {
			webview.goBack();
		}
		else {
			d.setTitle("YT CONVERTER👇");
			d.setMessage("Are you sure you want to exit?🤔");
			d.setPositiveButton("Yes🙂", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					finish();
				}
			});
			d.setNegativeButton("No😍", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			d.create().show();
		}
	}
	private void _Convert (final String _key, final boolean _mp3, final boolean _mp4) {
		if (!_key.trim().equals("")) {
			if (_key.contains("https://m.youtube.com/watch?v=")) {
				ip = _key.replace("https://m.youtube.com/watch?v=", "");
			}
			else {
				if (_key.contains("https://youtu.be/")) {
					ip = _key.replace("https://youtu.be/", "");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "error 11");
				}
			}
			if (ip.trim().equals("")) {
				SketchwareUtil.showMessage(getApplicationContext(), "ip bulunamadi");
			}
			else {
				load = "https://www.yt2mp3s.me/@api/button/mp3/".concat(ip);
				webview.loadUrl(load);
			}
		}
		else {
			
		}
	}
	
	
	private void _download_manager (final WebView _view, final String _path) {
		_view.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
				String cookies = CookieManager.getInstance().getCookie(url);
				request.addRequestHeader("cookie", cookies);
				request.addRequestHeader("User-Agent", userAgent);
				request.setDescription("Downloading file...");
				request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				 filename = URLUtil.guessFileName(url,contentDisposition,mimetype);
				calendar = Calendar.getInstance();
				filetime = new SimpleDateFormat("dd/mm/yyyy hh:mm:ss").format(calendar.getTime());
				request.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				java.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + _path);
				
				if(!aatv.exists()){
					if (!aatv.mkdirs()){
						Log.e("TravellerLog ::","Problem creating Image folder");}} request.setDestinationInExternalPublicDir(_path, URLUtil.guessFileName(url, contentDisposition, mimetype));
				DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				manager.enqueue(request);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						if (filename.trim().equals("")) {
							SketchwareUtil.showMessage(getApplicationContext(), "obs bir hata meydana geldi");
						}
						else {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("name", filename);
								_item.put("time", filetime);
								_item.put("path", _path);
								download_complete.add(_item);
							}
							download_data.edit().putString("download", new Gson().toJson(download_complete)).commit();
							
						}
						showMessage("Download Complete!");
						unregisterReceiver(this);
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
	}
	
	
	private void _Folders (final String _file_path) {
		if (FileUtil.isExistFile(_file_path)) {
			
		}
		else {
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/".concat(_file_path)));
		}
		if (FileUtil.isExistFile(_file_path.concat("/videos"))) {
			
		}
		else {
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/".concat(_file_path.concat("/videos"))));
		}
		if (FileUtil.isExistFile(_file_path.concat("/musics"))) {
			
		}
		else {
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/".concat(_file_path.concat("/musics"))));
		}
		if (FileUtil.isExistFile(_file_path.concat("/documentations"))) {
			
		}
		else {
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/".concat(_file_path.concat("/documentations"))));
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
